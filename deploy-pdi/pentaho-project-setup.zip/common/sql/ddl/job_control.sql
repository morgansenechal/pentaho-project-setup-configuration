CREATE TABLE job_control (
	batch_id int4,
	jobname varchar(50),
	status varchar(50),
	checkpoint varchar(50),
	logtime timestamp
);